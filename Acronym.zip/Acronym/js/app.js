// Defining Varible For Fetch Data From User

let getDataFromUser;

// Defining Variable For Contain Answer of Acronym

let answer;

// this area (Object) is For Keeping The Acronym Value

let acronymDatabase = {
  WWW: "[W]orld [W]ide [W]eb",

  HTML: "[H]yper [T]ext [M]arkUp [L]anguage",

  CSS: "[C]assading [S]tyle [S]heet",

  JS: "[J]ava [S]cript",

  PPS: "[P]re [P]roccessor [S]ystem",

  FlexBox: "[F]lexible [B]ox",

  PHP: "[P]]re [H]yper [P]roccessor"
};

// this is a function and have a calcute and process Acronym

let acronymFinder = () => {
  let getDataFromUser = document.getElementById("acronymReciver").value;

  switch (getDataFromUser) {
    case "WWW":
      answer = `The ${getDataFromUser} Acronym is : ${acronymDatabase.WWW}`;
      break;

    case "HTML":
      answer = `The ${getDataFromUser} Acronym is : ${acronymDatabase.HTML}`;

      break;

    case "CSS":
      answer = `The ${getDataFromUser} Acronym is : ${acronymDatabase.CSS}`;

      break;

    case "JS":
      answer = `The ${getDataFromUser} Acronym is : ${acronymDatabase.JS}`;

      break;

    case "PPS":
      answer = `The ${getDataFromUser} Acronym is : ${acronymDatabase.PPS}`;

      break;

    case "FlexBox":
      answer = `The ${getDataFromUser} Acronym is : ${acronymDatabase.FlexBox}`;

      break;

    case "PHP":
      answer = `The ${getDataFromUser} Acronym is : ${acronymDatabase.PHP}`;

      break;

    default:
      answer = `The ${getDataFromUser} its Not Defined In Our Acronym System`;
  }

  alert(answer);
};
